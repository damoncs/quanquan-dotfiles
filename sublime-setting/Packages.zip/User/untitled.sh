if [ ! -x $1 ];then
        chmod u+x $1
fi
        sh $1